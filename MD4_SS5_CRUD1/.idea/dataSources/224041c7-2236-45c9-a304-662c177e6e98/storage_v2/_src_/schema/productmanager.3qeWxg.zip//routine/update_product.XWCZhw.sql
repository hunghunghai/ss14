create
    definer = root@localhost procedure update_product(IN updateId int, IN newName varchar(255),
                                                      IN newDescription varchar(255), IN newPrice double,
                                                      IN newQuantity int, IN newUrlFile varchar(255))
begin
update products  set name = newName,description = newDescription,price = newPrice, quantity = newQuantity ,urlFile = newUrlFile where id = updateId;
end;

