create
    definer = root@localhost procedure get_product()
begin
    select * from products;
end;

