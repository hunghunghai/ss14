create
    definer = root@localhost procedure delete_product(IN idDelete int)
begin
    delete from products where id = idDelete;
end;

