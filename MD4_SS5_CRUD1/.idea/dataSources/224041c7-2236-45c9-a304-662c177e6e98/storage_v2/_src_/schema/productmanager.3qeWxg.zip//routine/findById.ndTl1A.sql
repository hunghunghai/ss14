create
    definer = root@localhost procedure findById(IN idFind int)
begin
    select * from products where idFind = id;
end;

