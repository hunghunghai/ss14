create
    definer = root@localhost procedure add_product(IN newName varchar(255), IN newDescription varchar(255),
                                                   IN newPrice double, IN newQuantity int, IN newUrlFile varchar(255))
begin
insert into products( name, description, price, quantity, urlFile)
    values (newName, newDescription, newPrice, newQuantity, newUrlFile);
end;

