create
    definer = root@localhost procedure searchByName(IN keyword varchar(255))
begin
    select * from products where name  like concat('%', keyword, '%');
end;

